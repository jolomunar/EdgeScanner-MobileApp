package apc.mobprog.myqrcodeandbarcodescanner;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.Button;
import android.widget.TextView;
import android.app.ProgressDialog;
import com.android.volley.Request;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import android.content.Context;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.net.URL;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import okhttp3.Response;
import okhttp3.ResponseBody;
import javax.net.ssl.HttpsURLConnection;

public class DisplayActivity extends AppCompatActivity {


    Button scanAgain;
    Button sendData;
    ListView listView;
    ArrayAdapter<String> arr;
    String esEndpoint = "https://edgescanner.herokuapp.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        Intent intent = getIntent();
        GlobalBarcode.barcode = intent.getStringExtra("barcode_nr");
        listView = findViewById(R.id.sampleListView);
        GlobalBarcode.arrayList = new ArrayList<>();
        arr = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice,
                Collections.singletonList(GlobalBarcode.barcode));
        listView.setAdapter(arr);

        for (int i = 0; i < GlobalBarcode.arrayList.size(); i++) {
            GlobalBarcode.arrayList.add(GlobalBarcode.barcode);
        }

        Toast.makeText(getApplicationContext(), GlobalBarcode.barcode, Toast.LENGTH_SHORT).show();
        beginOnClick();
    }

    public void beginOnClick() {
        scanAgain = findViewById(R.id.button2);
        sendData = findViewById(R.id.button4);

        //Scan Again Button
        scanAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reScan();
            }
        });
        //Send Data Button
        sendData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyAsyncTasks myAsyncTasks = new MyAsyncTasks();
                myAsyncTasks.execute();
            }
        });
    }

    public void reScan() {
        IntentIntegrator intentIntegrator = new IntentIntegrator(this);
        intentIntegrator.setOrientationLocked(true);
        intentIntegrator.setDesiredBarcodeFormats(intentIntegrator.ALL_CODE_TYPES);
        intentIntegrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult results = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        listView = findViewById(R.id.sampleListView);
        GlobalBarcode.arrayList = new ArrayList<>();
        arr = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, Collections.singletonList
                (results.getContents()));
        listView.setAdapter(arr);
        GlobalBarcode.arrayList.add(results.getContents());
        Toast.makeText(getApplicationContext(), results.getContents(), Toast.LENGTH_SHORT).show();

    }

    public class MyAsyncTasks extends AsyncTask<String, String, String> {

        ProgressDialog pD;
        private final String TAG = "Post";
        private Context data;

        public void Empty(Context set){
            this.data = set;
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Display Progress Dialog
            pD = new ProgressDialog(DisplayActivity.this);
            pD.setMessage("Processing Results");
            pD.setCancelable(false);
            pD.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            // Fetch data from API.

            String result = "";
            try {
                URL url;
                HttpURLConnection urlConnection = null;
                try {
                    url = new URL(esEndpoint);

                    //Open URL connection
                    urlConnection = (HttpURLConnection) url.openConnection();

                    InputStream in = urlConnection.getInputStream();

                    InputStreamReader isw = new InputStreamReader(in);

                    result = performPostCall(esEndpoint, new HashMap<String, String>() {
                        {
                            put("Accept", "application/json");
                            put("Content-Type", "application/json");
                        }
                    });

                    int data = isw.read();

                    while (data != -1) {
                        result += (char) data;
                        data = isw.read();

                    }

                    //Return to OnPostExecute method
                    return result;

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                return "Exception: " + e.getMessage();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pD.dismiss();

            try {

                JSONObject jsonObject = new JSONObject(s);

                JSONArray jsonArray1 = jsonObject.getJSONArray("barcode_nr");


                int index_no = 1;
                JSONObject jsonObject1 = jsonArray1.getJSONObject(index_no);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        public String performPostCall(String requestURL, HashMap<String, String> postDataParams) {
            URL url;
            String response = "" ;

            return response;
        }
    }
    }


