package apc.mobprog.myqrcodeandbarcodescanner;

import java.util.ArrayList;

public class GlobalBarcode {
    public static String barcode;
    public static ArrayList<String> arrayList;
}
